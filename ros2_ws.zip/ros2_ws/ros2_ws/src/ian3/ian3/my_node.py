import math

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState


class JointMotionNode(Node):

    def __init__(self):
        super().__init__('joint_motion')

        # 建立 /joint_states 發布器
        self.publisher = self.create_publisher(
            JointState,
            '/joint_states',
            10
        )

        # 每 0.05 秒執行一次，相當於 20 Hz
        self.timer_period = 0.05
        self.timer = self.create_timer(
            self.timer_period,
            self.publish_joint_states
        )

        # URDF 中的關節名稱
        self.joint_names = [
            'joint1',
            'joint2',
            'joint3',
            'left_finger_joint',
            'right_finger_joint'
        ]

        # 五組關節空間軌跡點
        # joint1、joint2、joint3 單位為 rad
        # 夾爪關節單位為 m
        self.waypoints = [
            [0.0,  0.0,  0.0,  -0.02, -0.02],
            [0.8,  0.5, -0.5,  -0.04, -0.04],
            [-0.8, 0.8,  0.3,   0.0,   0.0],
            [1.2, -0.5,  0.6,  -0.03, -0.03],
            [0.0,  0.0,  0.0,  -0.02, -0.02]
        ]

        # 每兩個軌跡點之間花 2 秒
        self.segment_duration = 2.0

        self.segment_index = 0
        self.segment_start_time = self.get_clock().now()

        self.get_logger().info(
            'Automatic joint motion started.'
        )

    def publish_joint_states(self):
        now = self.get_clock().now()

        elapsed = (
            now - self.segment_start_time
        ).nanoseconds / 1e9

        # 到達下一個軌跡點
        if elapsed >= self.segment_duration:
            self.segment_index = (
                self.segment_index + 1
            ) % len(self.waypoints)

            self.segment_start_time = now
            elapsed = 0.0

        start_index = self.segment_index
        end_index = (
            self.segment_index + 1
        ) % len(self.waypoints)

        start_position = self.waypoints[start_index]
        end_position = self.waypoints[end_index]

        # 0～1 的插值比例
        ratio = elapsed / self.segment_duration
        ratio = max(0.0, min(1.0, ratio))

        # 使用 cosine interpolation，讓移動較平滑
        smooth_ratio = (
            0.5 - 0.5 * math.cos(math.pi * ratio)
        )

        positions = []

        for start, end in zip(start_position, end_position):
            position = start + smooth_ratio * (end - start)
            positions.append(position)

        message = JointState()
        message.header.stamp = now.to_msg()
        message.name = self.joint_names
        message.position = positions

        self.publisher.publish(message)


def main(args=None):
    rclpy.init(args=args)

    node = JointMotionNode()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()